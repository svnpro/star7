import os
import logging
import subprocess
from telegram import Update, Document
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext

# Logging untuk debug
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# GANTI DENGAN TOKEN BOT ANDA
TOKEN = "6905480196:AAFplmx6gL8Tkc4pmpRYUCMwSQt_7NNOPpE"

# Direktori kerja bot
BOT_DIR = "/opt/telegram_shc_bot"
os.makedirs(BOT_DIR, exist_ok=True)

async def start(update: Update, context: CallbackContext):
    await update.message.reply_text("✅ Bot aktif! Kirimkan file Bash (.sh) untuk dienkripsi dengan SHC.")

async def help_command(update: Update, context: CallbackContext):
    await update.message.reply_text("💡 Kirimkan file .sh untuk dienkripsi dengan SHC, dan bot akan mengembalikan file terenkripsi.")

async def encrypt_bash(update: Update, context: CallbackContext):
    document: Document = update.message.document
    if not document.file_name.endswith(".sh"):
        await update.message.reply_text("❌ Hanya file .sh yang dapat dienkripsi!")
        return

    file_id = document.file_id
    original_filename = document.file_name
    file_path = os.path.join(BOT_DIR, original_filename)
    encrypted_file_path = file_path + ".x"

    try:
        # Debug: Log informasi file
        logger.info(f"Menerima file: {original_filename} (ID: {file_id})")

        # Unduh file dari Telegram
        await update.message.reply_text("🔄 Mengunduh file...")
        file_info = await context.bot.get_file(file_id)
        
        # Debug: Log URL file yang akan diunduh
        logger.info(f"URL unduhan: {file_info.file_path}")

        await file_info.download_to_drive(file_path)

        # Debug: Pastikan file sudah terunduh
        if not os.path.exists(file_path):
            logger.error("❌ Gagal mengunduh file, tidak ditemukan di sistem!")
            await update.message.reply_text("❌ Gagal mengunduh file!")
            return

        # Jalankan SHC untuk enkripsi
        await update.message.reply_text("🔐 Mengenkripsi file dengan SHC...")
        shc_result = subprocess.run(
            ["shc", "-f", file_path, "-o", encrypted_file_path], 
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )

        # Debug: Cek hasil output SHC
        if shc_result.returncode != 0:
            logger.error(f"SHC Error: {shc_result.stderr}")
            await update.message.reply_text(f"❌ Gagal mengenkripsi file! Error: {shc_result.stderr}")
            return

        # Debug: Pastikan file hasil enkripsi ada sebelum dikirim
        if not os.path.exists(encrypted_file_path):
            logger.error("❌ File hasil enkripsi tidak ditemukan!")
            await update.message.reply_text("❌ Terjadi kesalahan, file tidak bisa dikirim!")
            return

        # Kirim kembali file terenkripsi
        await update.message.reply_text("✅ Enkripsi selesai! Mengirimkan file...")
        await update.message.reply_document(document=encrypted_file_path)

        # Bersihkan file setelah dikirim
        os.remove(file_path)
        os.remove(encrypted_file_path)

    except Exception as e:
        logger.error(f"Terjadi kesalahan: {str(e)}")
        await update.message.reply_text(f"❌ Terjadi kesalahan: {str(e)}")

def main():
    application = Application.builder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.Document.ALL, encrypt_bash))

    logger.info("Bot sedang berjalan...")
    application.run_polling()

if __name__ == "__main__":
    main()