import os
import logging
from telegram import Update
from telegram.ext import Updater, CommandHandler, MessageHandler, filters, CallbackContext

# Logging untuk debug
logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

TOKEN = "6905480196:AAFplmx6gL8Tkc4pmpRYUCMwSQt_7NNOPpE"

def start(update: Update, context: CallbackContext) -> None:
    update.message.reply_text("✅ Bot aktif! Kirim file .sh untuk dienkripsi.")

def handle_document(update: Update, context: CallbackContext):
    try:
        file = update.message.document
        if file.file_size > 50 * 1024 * 1024:  # Batas 50MB
            update.message.reply_text("❌ File terlalu besar! Maks 50MB.")
            return

        # Unduh file
        file_path = f"./downloads/{file.file_name}"
        os.makedirs("./downloads", exist_ok=True)
        file.get_file().download(file_path)

        # Proses enkripsi dengan SHC
        enc_file = f"{file_path}.enc"
        shc_command = f"shc -f {file_path} -o {enc_file}"
        os.system(shc_command)

        # Kirim file hasil enkripsi
        update.message.reply_document(document=open(enc_file, "rb"))

    except Exception as e:
        logger.error(f"❌ Error: {e}")
        update.message.reply_text("⚠️ Terjadi error, coba lagi nanti.")

def error_handler(update: Update, context: CallbackContext):
    logger.error(f"Error: {context.error}")

def main():
    updater = Updater(TOKEN)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    dp.add_error_handler(error_handler)

    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
