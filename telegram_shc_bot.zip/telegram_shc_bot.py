import os
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext

# Token bot dari BotFather
TOKEN = "6905480196:AAFplmx6gL8Tkc4pmpRYUCMwSQt_7NNOPpE"

# Logging untuk debug
logging.basicConfig(format='%(asctime)s - %(levelname)s - %(message)s', level=logging.INFO)

# Fungsi menangani file .sh yang dikirim
async def handle_document(update: Update, context: CallbackContext) -> None:
    file = update.message.document
    if not file.file_name.endswith(".sh"):
        await update.message.reply_text("**Send Your File .sh**")
        return

    await update.message.reply_text("**Proses Encrypt......**")

    # Unduh file ke VPS
    file_path = f"/tmp/{file.file_name}"
    new_file = await file.get_file()
    await new_file.download_to_drive(file_path)

    # Enkripsi dengan SHC
    os.system(f"shc -f {file_path} -o {file_path}.bin")

    # Kirim hasil enkripsi
    await update.message.reply_document(document=open(f"{file_path}.bin", "rb"))

    # Hapus file sementara
    os.remove(file_path)
    os.remove(f"{file_path}.bin")

# Fungsi perintah /start
async def start(update: Update, context: CallbackContext) -> None:
    await update.message.reply_text("**Send Your File .sh**")

# Fungsi utama untuk menjalankan bot
def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))

    app.run_polling()

if __name__ == "__main__":
    main()