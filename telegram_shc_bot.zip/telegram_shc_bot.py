import os
import subprocess
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters
from telegram.constants import ParseMode

# GANTI DENGAN TOKEN BOT TELEGRAM ANDA
TOKEN = "6905480196:AAFplmx6gL8Tkc4pmpRYUCMwSQt_7NNOPpE"

async def start(update: Update, context):
    await update.message.reply_text("✅ Bot aktif! Kirimkan file Bash untuk dienkripsi.")

async def help_command(update: Update, context):
    await update.message.reply_text("💡 Kirimkan file .sh untuk dienkripsi dengan SHC.")

async def encrypt_bash(update: Update, context):
    file = update.message.document
    if not file.file_name.endswith(".sh"):
        await update.message.reply_text("❌ Hanya file .sh yang bisa dienkripsi!")
        return
    
    file_path = f"/opt/telegram_shc_bot/{file.file_name}"
    new_file = file.file_name.replace(".sh", ".sh.x")

    # Download file dari Telegram
    file_id = file.file_id
    new_file_path = file_path + ".x"

    await update.message.reply_text("🔄 Mengunduh file...")
    new_file_path = f"/opt/telegram_shc_bot/{new_file}"
    await context.bot.get_file(file_id).download(file_path)

    # Jalankan SHC untuk enkripsi
    await update.message.reply_text("🔐 Mengenkripsi file dengan SHC...")
    try:
        subprocess.run(["shc", "-f", file_path, "-o", new_file_path], check=True)
        await update.message.reply_document(document=new_file_path)
    except subprocess.CalledProcessError:
        await update.message.reply_text("❌ Gagal mengenkripsi file!")

def main():
    application = Application.builder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.Document.ALL, encrypt_bash))

    application.run_polling()

if __name__ == "__main__":
    main()