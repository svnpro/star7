#!/bin/bash
while true; do
    echo "🚀 Menjalankan bot..."
    python3 telegram_shc_bot.py
    echo "⚠️ Bot crash! Restarting..."
    sleep 5  # Tunggu 5 detik sebelum restart
done
